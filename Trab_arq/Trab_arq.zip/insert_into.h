#ifndef INSERT_INTO
#define INSERT_INTO

#include "funcoes_escrita.h"
#include "funcoes_leitura.h"
#include "funcoes_operacoes.h"

int insert_into(char *nomeArquivoEntrada, char *nomeArquivoSaida);

#endif