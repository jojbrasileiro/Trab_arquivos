#ifndef DELETE_FROM_H
#define DELETE_FROM_H

#include "funcoes_escrita.h"
#include "funcoes_leitura.h"
#include "funcoes_operacoes.h"
#include "create_index.h"

int delete_from(char *nomeArquivoEntrada, char *nomeArquivoSaida);

#endif