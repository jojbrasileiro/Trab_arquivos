#ifndef SELECT_FROM_H
#define SELECT_FROM_H

#include "funcoes_leitura.h"
#include "funcoes_escrita.h"
#include "funcoes_operacoes.h"

void select_from(char *nomeArquivoEntrada);

#endif
