#ifndef CREATE_TABLE_H
#define CREATE_TABLE_H

#include "funcoes_escrita.h"
#include "funcoes_leitura.h"
#include "funcoes_operacoes.h"

int create_table(char *nomeArquivoEntrada, char *nomeArquivoSaida);

#endif
