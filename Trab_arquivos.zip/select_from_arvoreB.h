#ifndef SELECT_FROM_ARVOREB_H
#define SELECT_FROM_ARVOREB_H

#include "funcoes_leitura.h"
#include "funcoes_escrita.h"
#include "funcoes_operacoes.h"
#include "b_tree.h"

void select_from_arvoreB(char *nomeArquivoEntrada, char *nomeArquivoIndice);

#endif
