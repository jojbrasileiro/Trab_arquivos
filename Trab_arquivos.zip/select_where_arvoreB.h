#ifndef SELECT_WHERE_ARVOREB_H
#define SELECT_WHERE_ARVOREB_H

#include "funcoes_leitura.h"
#include "funcoes_escrita.h"
#include "funcoes_operacoes.h"
#include "b_tree.h"

void select_where_arvoreB(char *nomeArquivoEntrada, char *nomeArquivoIndice);

#endif
